<?php
    include 'assets/php/classes/User.php';
    include 'assets/php/classes/Content.php';
    include 'assets/php/classes/Page.php';
?>