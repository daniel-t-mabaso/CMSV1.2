
<div class='card medium-width small-padding secondary-bg white-txt hide' id='pop-up'>
    <div id='close-pop-up' class='danger-txt float-right subheading cursor' onclick='closePopUp();'>&#10005;</div>
    <p id='pop-up-msg' class='center-txt'></p>
</div>