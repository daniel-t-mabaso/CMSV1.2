<?php

        include 'classes/User.php';
        include 'classes/Page.php';
        include 'classes/Content.php';

?>