<?php
    $dbc = mysqli_connect('localhost', 'goarmzps_cms', 'ROaYl*WX~29f', 'goarmzps_db');
?>